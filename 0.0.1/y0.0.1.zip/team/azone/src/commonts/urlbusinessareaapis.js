export const AJAXURL = 'http://localhost:3000/businessareaapis'
