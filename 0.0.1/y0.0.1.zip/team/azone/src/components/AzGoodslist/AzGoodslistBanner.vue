<template>
    <div>
      <div>
        <img src="../../../static/img/goodslist_banner.jpg" alt="">
      </div>
    </div>
</template>

<script>
    export default {
        name: "AzGoodslistBanner"
    }
</script>

<style scoped>
  img{
    width:100%;
    height:1.35rem;
  }
</style>
