<template>
  <div class="box">
    <nav>
      <div class="nav_left">
        <ul class="uls">
          <li v-for="(p,index) in see" v-on:click="addClass(index)" v-bind:class="{ lis:index==current}"><a
            href="javascript:;">{{p.title}}</a></li>
        </ul>
      </div>
      <div class="nav_right">
        <div class="nav_box">
          <div class="nav_banner">
            <a href="javascript:;" v-show="see[current].bansrc"><img :src="see[current].bansrc" alt=""></a>
            <div class="swiper-container" v-show="see[current].bansrcs">
              <div class="swiper-wrapper">
                <div class="swiper-slide" :key="index" v-for="(p,index) in see[current].bansrcs"><img :src="p.img" alt="">
                </div>
                <div class="swiper-pagination"></div>
              </div>
            </div>
          </div>
          <div class="nav_title">
            <p>{{see[current].bantitle}}</p>
          </div>
          <div class="hot_special">
            <a href="javascript:;" :key="index" v-for="(p,index) in see[current].special"><img :src="p" alt=""></a>

          </div>
          <div v-for="(m,index) in see[current].product">
            <div class="nav_titles">
              <p>{{m.bantitls}}</p>
            </div>
            <div class="hot_recommendation">
              <ul>
                <li :key="index" v-for="(d,index) in m.hot"><a href="/AzGoodslist"><img :src="d.a" alt=""><em>{{d.b}}</em></a>
                </li>

              </ul>
            </div>
          </div>
          <div class="nav_titlet">
            <em><img :src="see[current].bantitsrc" alt="">{{see[current].bantite}}</em>
          </div>
          <div class="recommendations">
            <ul>
              <li :key="index" v-for="(p,index) in see[current].recomm"><a href="#"><img :src="p.a"
                                                                                         alt=""><em>{{p.b}}</em></a>
              </li>
            </ul>
          </div>
          <img :src="see[current].pingdao" alt="" class="pingdao">
        </div>
      </div>
    </nav>
  </div>

</template>

<script>
  import Swiper from "swiper"

  export default {
    name: "AzClassificationBox",
    data() {
      return {
        current: 0,
        see: [
          {
            title: "热门推荐",
            bansrcs: [
              {"img":"../../../static/img/Classification_right1.jpg"},
              {"img":"../../../static/img/Classification_hot1.jpg"}
            ],
            bantitle: "热门家电",
            special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
            product:[
              {
                bantitls: "热门推荐",
                hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电视"},
                  {a: "../../../static/img/Classification_right3.jpg", b: "空调"},
                  {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                  {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                  {a: "../../../static/img/Classification_right6.png", b: "手机"},
                  {a: "../../../static/img/Classification_right7.png", b: "酒"},
                  {a: "../../../static/img/Classification_right8.jpg", b: "男装"},
                  {a: "../../../static/img/Classification_right9.jpg", b: "母婴"},
                  {a: "../../../static/img/Classification_right10.jpg", b: "运动"},
                ],
              }
            ],
            bantitsrc: "../../../static/img/Classification_right10.png",
            bantite: "为您推荐",
            recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
              {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
              {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
              {a: "../../../static/img/Classification_right14.jpg", b: "电动剃须刀"},
              {a: "../../../static/img/Classification_right15.jpg", b: "薯片"},
              {a: "../../../static/img/Classification_right10.jpg", b: "运动鞋"},
              {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
              {a: "../../../static/img/Classification_right8.jpg", b: "男装"},
              {a: "../../../static/img/Classification_right9.jpg", b: "母婴"},
            ]

          },
          {
            title: "大家电",
            bansrc: "../../../static/img/Classification_dajiadian1.jpg",
            product:[
              {
                bantitls: "电视",
                hot: [
                  {a: "../../../static/img/classify_dianshi1.jpg", b: "电视"},
                  {a: "../../../static/img/classify_dianshi2.jpg", b: "65吋电视"},
                  {a: "../../../static/img/classify_dianshi3.jpg", b: "55吋电视"},
                  {a: "../../../static/img/classify_dianshi4.jpg", b: "32吋电视"},
                  {a: "../../../static/img/classify_dianshi5.png", b: "4K超高清"},
                  {a: "../../../static/img/classify_dianshi6.png", b: "曲面电视"},
                  {a: "../../../static/img/classify_dianshi7.png", b: "海信"},
                  {a: "../../../static/img/classify_dianshi8.png", b: "夏普"},
                  {a: "../../../static/img/classify_dianshi9.png", b: "创维"},
                  {a: "../../../static/img/classify_dianshi10.png", b: "TCL"},
                  {a: "../../../static/img/classify_dianshi11.png", b: "三星"},
                  {a: "../../../static/img/classify_dianshi12.png", b: "小米"},
                  {a: "../../../static/img/classify_dianshi13.png", b: "长虹"},
                  {a: "../../../static/img/classify_dianshi14.png", b: "康佳"},
                  {a: "../../../static/img/classify_dianshi15.jpg", b: "PPTV"},
                  {a: "../../../static/img/classify_dianshi16.png", b: "飞利浦"},
                  {a: "../../../static/img/classify_dianshi17.png", b: "索尼"},
                  {a: "../../../static/img/classify_dianshi18.png", b: "先锋"},
                ],
              },
              {
                bantitls: "冰箱",
                hot: [
                  {a: "../../../static/img/classify_bingxiang1.jpg", b: "冰箱"},
                  {a: "../../../static/img/classify_bingxiang2.jpg", b: "对开门冰箱"},
                  {a: "../../../static/img/classify_bingxiang3.jpg", b: "多门冰箱"},
                  {a: "../../../static/img/classify_bingxiang4.jpg", b: "三门冰箱"},
                  {a: "../../../static/img/classify_bingxiang5.png", b: "十字对开门"},
                  {a: "../../../static/img/classify_bingxiang6.jpg", b: "双门冰箱"},
                  {a: "../../../static/img/classify_bingxiang7.jpg", b: "冷柜/冰吧"},
                  {a: "../../../static/img/classify_bingxiang8.jpg", b: "商用冷柜"},
                  {a: "../../../static/img/classify_bingxiang9.png", b: "红酒柜"},
                  {a: "../../../static/img/classify_bingxiang10.jpg", b: "海尔"},
                  {a: "../../../static/img/classify_bingxiang11.jpg", b: "西门子"},
                  {a: "../../../static/img/classify_bingxiang12.png", b: "美的"},
                  {a: "../../../static/img/classify_bingxiang13.jpg", b: "容声"},
                  {a: "../../../static/img/classify_bingxiang14.jpg", b: "美菱"},
                  {a: "../../../static/img/classify_bingxiang15.png", b: "博世"},
                  {a: "../../../static/img/classify_bingxiang16.png", b: "三星"},
                  {a: "../../../static/img/classify_bingxiang17.png", b: "冰洗配件"},
                  {a: "../../../static/img/classify_bingxiang18.png", b: "二手冰箱"},
                ],
              },
              {
                bantitls: "空调",
                hot: [
                  {a: "../../../static/img/classify_kongtiao1.png", b: "格力超品日"},
                  {a: "../../../static/img/classify_kongtiao2.jpg", b: "变频空调"},
                  {a: "../../../static/img/classify_kongtiao3.jpg", b: "家用空调"},
                  {a: "../../../static/img/classify_kongtiao4.jpg", b: "空调挂机"},
                  {a: "../../../static/img/classify_kongtiao5.jpg", b: "空调柜机"},
                  {a: "../../../static/img/classify_kongtiao6.jpg", b: "中央空调"},
                  {a: "../../../static/img/classify_kongtiao7.jpg", b: "健康空调"},
                  {a: "../../../static/img/classify_kongtiao8.jpg", b: "美的"},
                  {a: "../../../static/img/classify_kongtiao9.png", b: "格力"},
                  {a: "../../../static/img/classify_kongtiao10.jpg", b: "奥克斯"},
                  {a: "../../../static/img/classify_kongtiao11.png", b: "海尔"},
                  {a: "../../../static/img/classify_kongtiao12.png", b: "海信"},
                  {a: "../../../static/img/classify_kongtiao13.png", b: "科龙"},
                  {a: "../../../static/img/classify_kongtiao14.png", b: "TCL"},
                  {a: "../../../static/img/classify_kongtiao15.png", b: "长虹"},
                  {a: "../../../static/img/classify_kongtiao16.png", b: "志高"},
                  {a: "../../../static/img/classify_kongtiao17.png", b: "扬子"},
                  {a: "../../../static/img/classify_kongtiao18.jpg", b: "大金"},
                  {a: "../../../static/img/classify_kongtiao19.png", b: "三菱电机"},
                  {a: "../../../static/img/classify_kongtiao20.png", b: "空调安装"},
                  {a: "../../../static/img/classify_kongtiao21.png", b: "空调维修"},
                  {a: "../../../static/img/classify_kongtiao22.png", b: "空调回收"},
                ],
              },
              {
                bantitls: "洗衣机",
                hot: [
                  {a: "../../../static/img/classify_xiyiji1.jpg", b: "洗干一体机"},
                  {a: "../../../static/img/classify_xiyiji2.jpg", b: "滚筒洗衣机"},
                  {a: "../../../static/img/classify_xiyiji3.jpg", b: "波轮洗衣机"},
                  {a: "../../../static/img/classify_xiyiji4.jpg", b: "大容量洗衣机"},
                  {a: "../../../static/img/classify_xiyiji5.jpg", b: "迷你洗衣机"},
                  {a: "../../../static/img/classify_xiyiji6.jpg", b: "双缸洗衣机"},
                  {a: "../../../static/img/classify_xiyiji7.png", b: "干衣机"},
                  {a: "../../../static/img/classify_xiyiji8.jpg", b: "洗衣机服务"},
                  {a: "../../../static/img/classify_xiyiji9.jpg", b: "西门子"},
                  {a: "../../../static/img/classify_xiyiji10.jpg", b: "海尔"},
                  {a: "../../../static/img/classify_xiyiji11.jpg", b: "小天鹅"},
                  {a: "../../../static/img/classify_xiyiji12.png", b: "三洋"},
                  {a: "../../../static/img/classify_xiyiji13.png", b: "美的"},
                  {a: "../../../static/img/classify_xiyiji14.png", b: "松下"},
                  {a: "../../../static/img/classify_xiyiji15.png", b: "冰洗配件"},
                  {a: "../../../static/img/classify_xiyiji16.png", b: "二手洗衣机"},
                ],
              },
              {
                bantitls: "热水器",
                hot: [
                  {a: "../../../static/img/classify_reshuiqi1.jpg", b: "热水器"},
                  {a: "../../../static/img/classify_reshuiqi2.jpg", b: "电热水器"},
                  {a: "../../../static/img/classify_reshuiqi3.png", b: "燃气热水器"},
                  {a: "../../../static/img/classify_reshuiqi4.jpg", b: "厨宝"},
                  {a: "../../../static/img/classify_reshuiqi5.jpg", b: "浴霸"},
                  {a: "../../../static/img/classify_reshuiqi6.jpg", b: "空气能热水器"},
                  {a: "../../../static/img/classify_reshuiqi7.jpg", b: "即热式热水器"},
                  {a: "../../../static/img/classify_reshuiqi8.jpg", b: "太阳能热水器"},
                  {a: "../../../static/img/classify_reshuiqi9.jpg", b: "洁身器"},
                  {a: "../../../static/img/classify_reshuiqi10.jpg", b: "海尔热水器"},
                  {a: "../../../static/img/classify_reshuiqi11.jpg", b: "史密斯热水器"},
                  {a: "../../../static/img/classify_reshuiqi12.jpg", b: "美的热水器"},
                  {a: "../../../static/img/classify_reshuiqi13.jpg", b: "林内热水器"},
                  {a: "../../../static/img/classify_reshuiqi14.jpg", b: "万和热水器"},
                  {a: "../../../static/img/classify_reshuiqi15.jpg", b: "惠而浦热水器"}

                ],
              },
            ],
            pingdao:"../../../static/img/Classification_jiadian.jpg"

          },
          {
            title: "手机相册",
            bansrc: "../../../static/img/Classification_shouji1.jpg",
            product:[
              {
                bantitls: "大牌推荐",
                hot: [
                  {a: "../../../static/img/classify_shouji1.jpg", b: "苹果"},
                  {a: "../../../static/img/classify_shouji2.jpg", b: "小米"},
                  {a: "../../../static/img/classify_shouji3.jpg", b: "荣耀"},
                  {a: "../../../static/img/classify_shouji4.jpg", b: "华为"},
                  {a: "../../../static/img/classify_shouji5.jpg", b: "OPPO"},
                  {a: "../../../static/img/classify_shouji6.jpg", b: "vivo"},
                  {a: "../../../static/img/classify_shouji7.jpg", b: "诺基亚"},
                  {a: "../../../static/img/classify_shouji8.jpg", b: "努比亚"},
                  {a: "../../../static/img/classify_shouji9.jpg", b: "三星"},
                  {a: "../../../static/img/classify_shouji10.jpg", b: "魅族"},
                  {a: "../../../static/img/classify_shouji11.jpg", b: "美图"},
                  {a: "../../../static/img/classify_shouji12.jpg", b: "守护宝"}
                ],
              },
              {
                bantitls: "搞机达人",
                hot: [
                  {a: "../../../static/img/classify_daren1.jpg", b: "全部手机"},
                  {a: "../../../static/img/classify_daren2.jpg", b: "全面屏手机"},
                  {a: "../../../static/img/classify_daren3.jpg", b: "游戏手机"},
                  {a: "../../../static/img/classify_daren4.jpg", b: "拍照手机"},
                  {a: "../../../static/img/classify_daren5.jpg", b: "女性手机"},
                  {a: "../../../static/img/classify_daren6.png", b: "面部识别手机"},
                  {a: "../../../static/img/classify_daren7.jpg", b: "长续航手机"},
                  {a: "../../../static/img/classify_daren8.png", b: "指纹手机"},
                  {a: "../../../static/img/classify_daren9.jpg", b: "老人机"}
                ],
              },
              {
                bantitls: "手机配件",
                hot: [
                  {a: "../../../static/img/classify_peijian1.png", b: "手机壳"},
                  {a: "../../../static/img/classify_peijian2.png", b: "手机膜"},
                  {a: "../../../static/img/classify_peijian3.png", b: "数据线"},
                  {a: "../../../static/img/classify_peijian4.png", b: "移动电源"},
                  {a: "../../../static/img/classify_peijian5.png", b: "充电器"},
                  {a: "../../../static/img/classify_peijian6.jpg", b: "手机支架"},
                  {a: "../../../static/img/classify_peijian7.png", b: "自拍杆"},
                  {a: "../../../static/img/classify_peijian8.jpg", b: "无线充"},
                  {a: "../../../static/img/classify_peijian9.png", b: "手机耳机"},
                  {a: "../../../static/img/classify_peijian11.jpg", b: "蓝牙耳机"},
                  {a: "../../../static/img/classify_peijian12.png", b: "手机存储卡"},
                  {a: "../../../static/img/classify_peijian13.png", b: "手机电池"},
                ],
              },
              {
                bantitls: "手机服务",
                hot: [
                  {a: "../../../static/img/classify_fuwu1.jpg", b: "以旧换新"},
                  {a: "../../../static/img/classify_fuwu2.png", b: "手机维修"},
                  {a: "../../../static/img/classify_fuwu3.jpg", b: "二手优品"}
                ],
              },
              {
                bantitls: "运营商",
                hot: [
                  {a: "../../../static/img/classify_yunying1.jpg", b: "苏宁网厅"},
                  {a: "../../../static/img/classify_yunying2.jpg", b: "手机卡"},
                  {a: "../../../static/img/classify_yunying3.jpg", b: "宽带"},
                  {a: "../../../static/img/classify_yunying4.jpg", b: "抢靓号"},
                  {a: "../../../static/img/classify_yunying5.jpg", b: "话费充值"},
                  {a: "../../../static/img/classify_yunying6.jpg", b: "流量订购"}
                ],
              },
              {
                bantitls: "数码照摄",
                hot: [
                  {a: "../../../static/img/classify_xiangji1.jpg", b: "单反相机"},
                  {a: "../../../static/img/classify_xiangji2.jpg", b: "微单相机"},
                  {a: "../../../static/img/classify_xiangji3.jpg", b: "数码相机"},
                  {a: "../../../static/img/classify_xiangji4.jpg", b: "摄像机"},
                  {a: "../../../static/img/classify_xiangji5.jpg", b: "镜头"},
                  {a: "../../../static/img/classify_xiangji6.jpg", b: "拍立得"},
                  {a: "../../../static/img/classify_xiangji7.jpg", b: "运动相机"},
                  {a: "../../../static/img/classify_xiangji8.jpg", b: "佳能相机"},
                  {a: "../../../static/img/classify_xiangji9.png", b: "尼康相机"},
                  {a: "../../../static/img/classify_xiangji10.jpg", b: "索尼"},
                  {a: "../../../static/img/classify_xiangji11.jpg", b: "富士相机"},
                  {a: "../../../static/img/classify_xiangji12.jpg", b: "Gopro相机"}
                ],
              },
              {
                bantitls: "相机配件",
                hot: [
                  {a: "../../../static/img/classify_xpeijian1.jpg", b: "相机包"},
                  {a: "../../../static/img/classify_xpeijian2.jpg", b: "三脚架/云台"},
                  {a: "../../../static/img/classify_xpeijian3.jpg", b: "滤镜"},
                  {a: "../../../static/img/classify_xpeijian4.jpg", b: "相机存储卡"},
                  {a: "../../../static/img/classify_xpeijian5.jpg", b: "闪光灯"},
                  {a: "../../../static/img/classify_xpeijian6.jpg", b: "影棚器材"},
                ],
              },
              {
                bantitls: "配件品牌",
                hot: [
                  {a: "../../../static/img/classify_xpingpan1.jpg", b: "国家地理包"},
                  {a: "../../../static/img/classify_xpingpan2.jpg", b: "腾龙镜头"},
                  {a: "../../../static/img/classify_xpingpan3.jpg", b: "适马镜头"},
                ],
              },
            ],
            pingdao:"../../../static/img/Classification_phone.jpg"

          },
          {
            title: "电脑办公",
            bansrc: "../../../static/img/Classification_computer1.jpg",
            product:[
              {
                bantitls: "电脑整机",
                hot: [
                  {a: "../../../static/img/classify_zhengji1.jpg", b: "笔记本"},
                  {a: "../../../static/img/classify_zhengji2.png", b: "游戏本"},
                  {a: "../../../static/img/classify_zhengji3.jpg", b: "轻薄本"},
                  {a: "../../../static/img/classify_zhengji4.jpg", b: "平板电脑"},
                  {a: "../../../static/img/classify_zhengji5.jpg", b: "台式机"},
                  {a: "../../../static/img/classify_zhengji6.jpg", b: "一体机"},
                  {a: "../../../static/img/classify_zhengji7.png", b: "游戏台式机"},
                  {a: "../../../static/img/classify_zhengji8.png", b: "商用台式机"},
                  {a: "../../../static/img/classify_zhengji9.png", b: "组装机"},
                  {a: "../../../static/img/classify_zhengji11.png", b: "二手优品"},
                  {a: "../../../static/img/classify_zhengji12.png", b: "替客检"},
                  {a: "../../../static/img/classify_zhengji13.png", b: "以旧换新服务"},
                ],
              },
              {
                bantitls: "电脑外设",
                hot: [
                  {a: "../../../static/img/classify_waishe1.jpg", b: "U盘"},
                  {a: "../../../static/img/classify_waishe2.jpg", b: "鼠标"},
                  {a: "../../../static/img/classify_waishe3.jpg", b: "键盘"},
                  {a: "../../../static/img/classify_waishe4.png", b: "机械键盘"},
                  {a: "../../../static/img/classify_waishe5.jpg", b: "键鼠套装"},
                  {a: "../../../static/img/classify_waishe6.jpg", b: "移动硬盘"},
                  {a: "../../../static/img/classify_waishe7.jpg", b: "电脑音箱"},
                  {a: "../../../static/img/classify_waishe8.png", b: "鼠标垫"},
                  {a: "../../../static/img/classify_waishe9.png", b: "电池"},
                ],
              },
              {
                bantitls: "办公设备",
                hot: [
                  {a: "../../../static/img/classify_bangong1.jpg", b: "打印机"},
                  {a: "../../../static/img/classify_bangong2.jpg", b: "投影仪"},
                  {a: "../../../static/img/classify_bangong3.jpg", b: "复印机"},
                  {a: "../../../static/img/classify_bangong4.jpg", b: "保险柜"},
                  {a: "../../../static/img/classify_bangong5.jpg", b: "扫描仪"},
                  {a: "../../../static/img/classify_bangong6.jpg", b: "点验钞机"},
                  {a: "../../../static/img/classify_bangong7.png", b: "硒鼓"},
                  {a: "../../../static/img/classify_bangong8.png", b: "墨盒"},
                  {a: "../../../static/img/classify_bangong9.png", b: "色带架"},

                ],
              },
              {
                bantitls: "文具用品",
                hot: [
                  {a: "../../../static/img/classify_wenju1.jpg", b: "笔类"},
                  {a: "../../../static/img/classify_wenju2.jpg", b: "办公文具"},
                  {a: "../../../static/img/classify_wenju3.jpg", b: "办公用纸"},
                  {a: "../../../static/img/classify_wenju4.jpg", b: "学生文具"},
                  {a: "../../../static/img/classify_wenju5.jpg", b: "文件管理"},
                  {a: "../../../static/img/classify_wenju6.jpg", b: "本册/便签"},
                ],
              },
            ],
            pingdao:"../../../static/img/Classification_computer.jpg"

          },
          {
            title: "厨卫大电",
            bansrc: "../../../static/img/Classification_jiadian1.jpg",
            product:[
              {
                bantitls: "油烟机",
                hot: [
                  {a: "../../../static/img/classify_youyanji1.jpg", b: "油烟机"},
                  {a: "../../../static/img/classify_youyanji2.jpg", b: "烟灶套餐"},
                  {a: "../../../static/img/classify_youyanji3.jpg", b: "燃气灶"},
                  {a: "../../../static/img/classify_youyanji4.jpg", b: "商用电器"},
                  {a: "../../../static/img/classify_youyanji5.jpg", b: "集成灶"},
                  {a: "../../../static/img/classify_youyanji6.jpg", b: "厨余粉碎机"},
                  {a: "../../../static/img/classify_youyanji7.jpg", b: "老板"},
                  {a: "../../../static/img/classify_youyanji8.png", b: "方太"},
                  {a: "../../../static/img/classify_youyanji9.jpg", b: "海尔"},
                ],
              },
              {
                bantitls: "热水器",
                hot: [
                  {a: "../../../static/img/classify_reshuiqi1.jpg", b: "热水器"},
                  {a: "../../../static/img/classify_reshuiqi2.jpg", b: "电热水器"},
                  {a: "../../../static/img/classify_reshuiqi3.png", b: "燃气热水器"},
                  {a: "../../../static/img/classify_reshuiqi4.jpg", b: "厨宝"},
                  {a: "../../../static/img/classify_reshuiqi5.jpg", b: "浴霸"},
                  {a: "../../../static/img/classify_reshuiqi6.jpg", b: "空气能热水器"},
                  {a: "../../../static/img/classify_reshuiqi7.jpg", b: "即热式热水器"},
                  {a: "../../../static/img/classify_reshuiqi8.jpg", b: "太阳能热水器"},
                  {a: "../../../static/img/classify_reshuiqi9.jpg", b: "洁身器"},
                  {a: "../../../static/img/classify_reshuiqi10.jpg", b: "海尔热水器"},
                  {a: "../../../static/img/classify_reshuiqi11.jpg", b: "史密斯热水器"},
                  {a: "../../../static/img/classify_reshuiqi12.jpg", b: "美的热水器"},
                  {a: "../../../static/img/classify_reshuiqi13.jpg", b: "林内热水器"},
                  {a: "../../../static/img/classify_reshuiqi14.jpg", b: "万和热水器"},
                  {a: "../../../static/img/classify_reshuiqi15.jpg", b: "惠而浦热水器"}

                ],
              },
              {
                bantitls: "洗碗机",
                hot: [
                  {a: "../../../static/img/classify_xiwanji1.jpg", b: "洗碗机"},
                  {a: "../../../static/img/classify_xiwanji2.png", b: "电蒸炉"},
                  {a: "../../../static/img/classify_xiwanji3.jpg", b: "消毒柜"},
                  {a: "../../../static/img/classify_xiwanji4.png", b: "烤箱"},
                  {a: "../../../static/img/classify_xiwanji5.png", b: "微波炉"},
                  {a: "../../../static/img/classify_xiwanji6.jpg", b: "美的"},
                  {a: "../../../static/img/classify_xiwanji7.jpg", b: "西门子"},
                  {a: "../../../static/img/classify_xiwanji8.jpg", b: "康宝"},
                  {a: "../../../static/img/classify_xiwanji9.jpg", b: "老板"},

                ],
              },
              {
                bantitls: "净水器",
                hot: [
                  {a: "../../../static/img/classify_jingshuiqi1.jpg", b: "净水器"},
                  {a: "../../../static/img/classify_jingshuiqi2.jpg", b: "饮水机"},
                  {a: "../../../static/img/classify_jingshuiqi3.jpg", b: "前置过滤器"},
                  {a: "../../../static/img/classify_jingshuiqi4.jpg", b: "净水杯"},
                  {a: "../../../static/img/classify_jingshuiqi5.jpg", b: "沁园"},
                  {a: "../../../static/img/classify_jingshuiqi6.jpg", b: "史密斯净水器"},
                  {a: "../../../static/img/classify_jingshuiqi7.jpg", b: "美的"},
                  {a: "../../../static/img/classify_jingshuiqi8.jpg", b: "安吉尔"},
                  {a: "../../../static/img/classify_jingshuiqi9.jpg", b: "3M"},
                ],
              },
            ],
            pingdao:"../../../static/img/Classification_kitchen.jpg"

          },
          {
            title: "生活家电",
            bansrc: "../../../static/img/Classification_shouji2.jpg",
            product:[
              {
                bantitls: "热门推荐",
                hot: [
                  {a: "../../../static/img/classify_lifehot1.jpg", b: "取暖器"},
                  {a: "../../../static/img/classify_lifehot2.jpg", b: "电热毯"},
                  {a: "../../../static/img/classify_lifehot3.jpg", b: "破壁机"},
                  {a: "../../../static/img/classify_lifehot4.jpg", b: "电火锅"},
                  {a: "../../../static/img/classify_lifehot5.jpg", b: "电炖锅"},
                  {a: "../../../static/img/classify_lifehot6.jpg", b: "空气净化器"},
                  {a: "../../../static/img/classify_lifehot7.jpg", b: "咖啡机"},
                  {a: "../../../static/img/classify_lifehot8.jpg", b: "养生壶"},
                  {a: "../../../static/img/classify_lifehot9.jpg", b: "足浴盆"},
                ],
              },
              {
                bantitls: "厨房家电",
                hot: [
                  {a: "../../../static/img/classify_chufang1.jpg", b: "电饭煲"},
                  {a: "../../../static/img/classify_chufang2.png", b: "电压力锅"},
                  {a: "../../../static/img/classify_chufang3.jpg", b: "微波炉"},
                  {a: "../../../static/img/classify_chufang4.jpg", b: "烤箱"},
                  {a: "../../../static/img/classify_chufang5.jpg", b: "电磁炉"},
                  {a: "../../../static/img/classify_chufang6.jpg", b: "豆浆机"},
                  {a: "../../../static/img/classify_chufang7.jpg", b: "破壁机"},
                  {a: "../../../static/img/classify_chufang8.jpg", b: "电火锅"},
                  {a: "../../../static/img/classify_chufang9.jpg", b: "榨汁/原汁机"},
                  {a: "../../../static/img/classify_chufang10.jpg", b: "咖啡机"},
                  {a: "../../../static/img/classify_chufang11.jpg", b: "面包机"},
                  {a: "../../../static/img/classify_chufang12.jpg", b: "养生壶"},
                  {a: "../../../static/img/classify_chufang13.jpg", b: "电饼铛"},
                  {a: "../../../static/img/classify_chufang14.png", b: "电水壶"},
                  {a: "../../../static/img/classify_chufang15.jpg", b: "电蒸锅"},
                  {a: "../../../static/img/classify_chufang16.jpg", b: "电陶炉"},
                  {a: "../../../static/img/classify_chufang17.jpg", b: "酸奶机"},
                  {a: "../../../static/img/classify_chufang18.jpg", b: "煮蛋器"},
                  {a: "../../../static/img/classify_chufang19.jpg", b: "打蛋器"},
                  {a: "../../../static/img/classify_chufang20.jpg", b: "电热饭盒"},
                  {a: "../../../static/img/classify_chufang21.jpg", b: "面条机"},
                  {a: "../../../static/img/classify_chufang22.jpg", b: "电炖锅/盅 "},
                  {a: "../../../static/img/classify_chufang23.jpg", b: "空气炸锅"},
                  {a: "../../../static/img/classify_chufang24.jpg", b: "电烧烤炉"},
                  {a: "../../../static/img/classify_chufang25.jpg", b: "多士炉"},
                  {a: "../../../static/img/classify_chufang26.jpg", b: "美的"},
                  {a: "../../../static/img/classify_chufang27.jpg", b: "九阳"},
                  {a: "../../../static/img/classify_chufang28.jpg", b: "苏泊尔"},
                  {a: "../../../static/img/classify_chufang29.jpg", b: "格兰仕"},
                  {a: "../../../static/img/classify_chufang30.jpg", b: "东菱"},
                ],
              },
              {
                bantitls: "洗碗机",
                hot: [
                  {a: "../../../static/img/classify_xiwanji1.jpg", b: "洗碗机"},
                  {a: "../../../static/img/classify_xiwanji2.png", b: "电蒸炉"},
                  {a: "../../../static/img/classify_xiwanji3.jpg", b: "消毒柜"},
                  {a: "../../../static/img/classify_xiwanji4.png", b: "烤箱"},
                  {a: "../../../static/img/classify_xiwanji5.png", b: "微波炉"},
                  {a: "../../../static/img/classify_xiwanji6.jpg", b: "美的"},
                  {a: "../../../static/img/classify_xiwanji7.jpg", b: "西门子"},
                  {a: "../../../static/img/classify_xiwanji8.jpg", b: "康宝"},
                  {a: "../../../static/img/classify_xiwanji9.jpg", b: "老板"},

                ],
              },
              {
                bantitls: "净水器",
                hot: [
                  {a: "../../../static/img/classify_jingshuiqi1.jpg", b: "净水器"},
                  {a: "../../../static/img/classify_jingshuiqi2.jpg", b: "饮水机"},
                  {a: "../../../static/img/classify_jingshuiqi3.jpg", b: "前置过滤器"},
                  {a: "../../../static/img/classify_jingshuiqi4.jpg", b: "净水杯"},
                  {a: "../../../static/img/classify_jingshuiqi5.jpg", b: "沁园"},
                  {a: "../../../static/img/classify_jingshuiqi6.jpg", b: "史密斯净水器"},
                  {a: "../../../static/img/classify_jingshuiqi7.jpg", b: "美的"},
                  {a: "../../../static/img/classify_jingshuiqi8.jpg", b: "安吉尔"},
                  {a: "../../../static/img/classify_jingshuiqi9.jpg", b: "3M"},
                ],
              },
            ],
            pingdao:"../../../static/img/Classification_life.jpg"
          },
          {
            title: "食品酒水",
            bansrc: "../../../static/img/classify_jiu.jpg",
            product:[
              {
                bantitls: "精选品类",
                hot: [
                  {a: "../../../static/img/classify_jingping1.jpg", b: "白酒"},
                  {a: "../../../static/img/classify_jingping2.jpg", b: "养生酒"},
                  {a: "../../../static/img/classify_jingping3.jpg", b: "饮用水"},
                  {a: "../../../static/img/classify_jingping4.jpg", b: "蜂蜜"},
                  {a: "../../../static/img/classify_jingping5.jpg", b: "葡萄酒"},
                  {a: "../../../static/img/classify_jingping6.png", b: "酸奶"},
                  {a: "../../../static/img/classify_jingping7.jpg", b: "麦片/谷物"},
                  {a: "../../../static/img/classify_jingping8.png", b: "纯奶"},
                  {a: "../../../static/img/classify_jingping9.jpg", b: "坚果"},
                  {a: "../../../static/img/classify_jingping10.jpg", b: "茶饮料"},
                  {a: "../../../static/img/classify_jingping11.jpg", b: "咖啡"},
                  {a: "../../../static/img/classify_jingping12.jpg", b: "方便粥"},
                  {a: "../../../static/img/classify_jingping13.jpg", b: "薯片"},
                  {a: "../../../static/img/classify_jingping14.jpg", b: "糕点点心"},
                  {a: "../../../static/img/classify_jingping15.jpg", b: "成人奶粉"},
                  {a: "../../../static/img/classify_jingping16.jpg", b: "奶茶"},
                  {a: "../../../static/img/classify_jingping17.jpg", b: "糖果"},
                  {a: "../../../static/img/classify_jingping18.jpg", b: "蜜饯/果脯"}
                ],
              },
              {
                bantitls: "牛奶冲调",
                hot: [
                  {a: "../../../static/img/classify_milk1.png", b: "纯牛奶"},
                  {a: "../../../static/img/classify_milk2.png", b: "酸奶"},
                  {a: "../../../static/img/classify_milk3.jpg", b: "风味奶"},
                  {a: "../../../static/img/classify_milk4.jpg", b: "成人奶粉"},
                  {a: "../../../static/img/classify_milk5.jpg", b: "茗茶"},
                  {a: "../../../static/img/classify_milk6.jpg", b: "咖啡"},
                  {a: "../../../static/img/classify_milk7.jpg", b: "蜂蜜"},
                  {a: "../../../static/img/classify_milk8.jpg", b: "麦片"},
                  {a: "../../../static/img/classify_milk9.jpg", b: "红茶"},

                ],
              },
            ],
            pingdao:"../../../static/img/classify_food2.jpg"
          },
          {
            title: "居家生活",
            bansrc: "../../../static/img/classify_food1.png",
            product:[
              {
                bantitls: "生活用纸",
                hot: [
                  {a: "../../../static/img/classify_zhi1.jpg", b: "卷纸"},
                  {a: "../../../static/img/classify_zhi2.jpg", b: "抽纸"},
                  {a: "../../../static/img/classify_zhi3.jpg", b: "手帕纸"},
                  {a: "../../../static/img/classify_zhi4.jpg", b: "厨房用纸"},
                  {a: "../../../static/img/classify_zhi5.jpg", b: "平板纸"},
                  {a: "../../../static/img/classify_zhi6.jpg", b: "湿巾纸"}
                ],
              },
              {
                bantitls: "家庭清洁",
                hot: [
                  {a: "../../../static/img/classify_qingjie1.jpg", b: "洗衣液"},
                  {a: "../../../static/img/classify_qingjie2.jpg", b: "洗衣粉"},
                  {a: "../../../static/img/classify_qingjie3.jpg", b: "洗洁精"},
                  {a: "../../../static/img/classify_qingjie4.jpg", b: "消毒液"},
                  {a: "../../../static/img/classify_qingjie5.jpg", b: "洁厕剂"},
                  {a: "../../../static/img/classify_qingjie6.jpg", b: "百洁布"},
                  {a: "../../../static/img/classify_qingjie7.jpg", b: "垃圾袋"},
                  {a: "../../../static/img/classify_qingjie8.jpg", b: "保鲜袋"},
                  {a: "../../../static/img/classify_qingjie9.jpg", b: "保鲜膜"},

                ],
              },
              {
                bantitls: "生活日用",
                hot: [
                  {a: "../../../static/img/classify_shenghuo1.jpg", b: "收纳用品"},
                  {a: "../../../static/img/classify_shenghuo2.jpg", b: "保温器具"},
                  {a: "../../../static/img/classify_shenghuo3.jpg", b: "保温杯"},
                  {a: "../../../static/img/classify_shenghuo4.jpg", b: "保温瓶/桶"},
                  {a: "../../../static/img/classify_shenghuo5.jpg", b: "酒具"},
                  {a: "../../../static/img/classify_shenghuo6.jpg", b: "晴雨用具"},
                  {a: "../../../static/img/classify_shenghuo7.jpg", b: "家居器皿"},
                  {a: "../../../static/img/classify_shenghuo8.jpg", b: "保鲜盒"},
                  {a: "../../../static/img/classify_shenghuo9.jpg", b: "净化除味"},
                  {a: "../../../static/img/classify_shenghuo10.jpg", b: "电动晾晒架"},
                  {a: "../../../static/img/classify_shenghuo11.jpg", b: "洗晒用品"},
                  {a: "../../../static/img/classify_shenghuo12.jpg", b: "口罩"},
                  {a: "../../../static/img/classify_shenghuo13.jpg", b: "浴室用品"},
                  {a: "../../../static/img/classify_shenghuo14.jpg", b: "压缩袋"},
                  {a: "../../../static/img/classify_shenghuo15.jpg", b: "香薰用品"},
                  {a: "../../../static/img/classify_shenghuo16.jpg", b: "保暖用品"},
                  {a: "../../../static/img/classify_shenghuo17.jpg", b: "缝纫/针织"},
                  {a: "../../../static/img/classify_shenghuo18.jpg", b: "装饰用品"},
                  {a: "../../../static/img/classify_shenghuo19.jpg", b: "十字绣"},
                  {a: "../../../static/img/classify_shenghuo20.jpg", b: "照片墙"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_jujia.jpg"
          },
          {
            title: "品质男装",
            bansrc: "../../../static/img/classify_nanzhuang.jpg",
            product:[
              {
                bantitls: "羽绒服",
                hot: [
                  {a: "../../../static/img/classify_yuchongfu1.jpg", b: "短款羽绒服"},
                  {a: "../../../static/img/classify_yuchongfu2.jpg", b: "中长款羽绒服"},
                  {a: "../../../static/img/classify_yuchongfu3.jpg", b: "中老年羽绒服"},
                ],
              },
              {
                bantitls: "热卖分类",
                hot: [
                  {a: "../../../static/img/classify_remai1.jpg", b: "羽绒服"},
                  {a: "../../../static/img/classify_remai2.jpg", b: "长袖T恤"},
                  {a: "../../../static/img/classify_remai3.jpg", b: "男士夹克"},
                  {a: "../../../static/img/classify_remai4.jpg", b: "男士外套"},
                  {a: "../../../static/img/classify_remai5.jpg", b: "休闲裤"},
                  {a: "../../../static/img/classify_remai6.jpg", b: "牛仔裤"},
                ],
              },
              {
                bantitls: "衬衫",
                hot: [
                  {a: "../../../static/img/classify_chenyi1.jpg", b: "免烫衬衫"},
                  {a: "../../../static/img/classify_chenyi2.jpg", b: "长袖衬衫"},
                  {a: "../../../static/img/classify_chenyi3.jpg", b: "格子衬衫"},
                  {a: "../../../static/img/classify_chenyi4.jpg", b: "牛仔衬衫"},
                  {a: "../../../static/img/classify_chenyi5.jpg", b: "条纹衬衫"},
                  {a: "../../../static/img/classify_chenyi6.jpg", b: "短袖衬衫"},
                ],
              },
              {
                bantitls: "男士外套",
                hot: [
                  {a: "../../../static/img/classify_waitao1.jpg", b: "夹克"},
                  {a: "../../../static/img/classify_waitao2.jpg", b: "牛仔外套"},
                  {a: "../../../static/img/classify_waitao3.jpg", b: "西装套装"},
                  {a: "../../../static/img/classify_waitao4.jpg", b: "棒球服"},
                  {a: "../../../static/img/classify_waitao5.jpg", b: "风衣"},
                  {a: "../../../static/img/classify_waitao6.jpg", b: "单西"},
                ],
              },
              {
                bantitls: "牛仔裤",
                hot: [
                  {a: "../../../static/img/classify_niuzaiku1.jpg", b: "修身牛仔裤"},
                  {a: "../../../static/img/classify_niuzaiku2.jpg", b: "破洞牛仔裤"},
                  {a: "../../../static/img/classify_niuzaiku3.jpg", b: "直筒牛仔裤"},
                  {a: "../../../static/img/classify_niuzaiku4.jpg", b: "弹力牛仔裤"},
                  {a: "../../../static/img/classify_niuzaiku5.jpg", b: "束脚牛仔裤"},
                  {a: "../../../static/img/classify_niuzaiku6.jpg", b: "牛仔短裤"},
                ],
              },
              {
                bantitls: "休闲裤",
                hot: [
                  {a: "../../../static/img/classify_xiuxianku1.jpg", b: "修身版型"},
                  {a: "../../../static/img/classify_xiuxianku2.jpg", b: "直筒版型"},
                  {a: "../../../static/img/classify_xiuxianku3.jpg", b: "宽松版型"},
                  {a: "../../../static/img/classify_xiuxianku4.jpg", b: "商务休闲"},
                  {a: "../../../static/img/classify_xiuxianku5.png", b: "束脚裤男"},
                  {a: "../../../static/img/classify_xiuxianku6.jpg", b: "迷彩裤"},
                ],
              },
              {
                bantitls: "时尚潮流",
                hot: [
                  {a: "../../../static/img/classify_shizhuang1.jpg", b: "美特斯邦威"},
                  {a: "../../../static/img/classify_shizhuang2.jpg", b: "骆驼男装"},
                  {a: "../../../static/img/classify_shizhuang3.jpg", b: "马克华菲"},
                  {a: "../../../static/img/classify_shizhuang4.jpg", b: "viishow"},
                  {a: "../../../static/img/classify_shizhuang5.jpg", b: "雅鹿"},
                  {a: "../../../static/img/classify_shizhuang6.jpg", b: "森马"},
                  {a: "../../../static/img/classify_shizhuang7.jpg", b: "GXG"},
                  {a: "../../../static/img/classify_shizhuang8.jpg", b: "海一家"},
                  {a: "../../../static/img/classify_shizhuang9.jpg", b: "黑鲸"},
                  {a: "../../../static/img/classify_shizhuang10.jpg", b: "迪尔马奇"},
                  {a: "../../../static/img/classify_shizhuang11.jpg", b: "圣沃斯"},
                  {a: "../../../static/img/classify_shizhuang12.jpg", b: "Jeep旗舰店"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_nanzhuang2.jpg"
          },
          {
            title: "运动户外",
            bansrc: "../../../static/img/classify_yundong.jpg",
            product:[
              {
                bantitls: "精选品牌",
                hot: [
                  {a: "../../../static/img/classify_playbrands1.jpg"},
                  {a: "../../../static/img/classify_playbrands2.jpg"},
                  {a: "../../../static/img/classify_playbrands3.jpg"},
                  {a: "../../../static/img/classify_playbrands4.jpg"},
                  {a: "../../../static/img/classify_playbrands5.jpg"},
                  {a: "../../../static/img/classify_playbrands6.jpg"},
                  {a: "../../../static/img/classify_playbrands7.jpg"},
                  {a: "../../../static/img/classify_playbrands8.jpg"},
                  {a: "../../../static/img/classify_playbrands9.jpg"},

                ],
              },
              {
                bantitls: "热门推荐",
                hot: [
                  {a: "../../../static/img/classify_playhot1.png", b: "运动羽绒服"},
                  {a: "../../../static/img/classify_playhot2.jpg", b: "跑步鞋"},
                  {a: "../../../static/img/classify_playhot3.jpg", b: "冲锋衣/裤"},
                  {a: "../../../static/img/classify_playhot4.jpg", b: "运动夹克"},
                  {a: "../../../static/img/classify_playhot5.jpg", b: "运动长裤"},
                  {a: "../../../static/img/classify_playhot6.jpg", b: "跑步机"},
                  {a: "../../../static/img/classify_playhot7.jpg", b: "自行车"},
                  {a: "../../../static/img/classify_playhot8.jpg", b: "钓竿"},
                  {a: "../../../static/img/classify_playhot9.jpg", b: "篮球鞋"},
                  {a: "../../../static/img/classify_playhot10.jpg", b: "足球"},
                  {a: "../../../static/img/classify_playhot11.jpg", b: "足球装备"},
                ],
              },
              {
                bantitls: "运动服饰",
                hot: [
                  {a: "../../../static/img/classify_playclothes1.png", b: "运动羽绒服"},
                  {a: "../../../static/img/classify_playclothes2.jpg", b: "运动夹克"},
                  {a: "../../../static/img/classify_playclothes3.jpg", b: "运动风衣"},
                  {a: "../../../static/img/classify_playclothes4.jpg", b: "运动卫衣"},
                  {a: "../../../static/img/classify_playclothes5.jpg", b: "运动长裤"},
                  {a: "../../../static/img/classify_playclothes6.jpg", b: "健身服"},
                  {a: "../../../static/img/classify_playclothes7.jpg", b: "运动套装"},
                  {a: "../../../static/img/classify_playclothes8.jpg", b: "运动短裤"},
                  {a: "../../../static/img/classify_playclothes9.jpg", b: "皮肤衣"},
                  {a: "../../../static/img/classify_playclothes10.jpg", b: "运动T恤"},
                  {a: "../../../static/img/classify_playclothes11.jpg", b: "棉服"},

                ],
              },
              {
                bantitls: "运动鞋",
                hot: [
                  {a: "../../../static/img/classify_yundongxie1.jpg", b: "跑步鞋"},
                  {a: "../../../static/img/classify_yundongxie2.jpg", b: "休闲板鞋"},
                  {a: "../../../static/img/classify_yundongxie3.jpg", b: "足球鞋"},
                  {a: "../../../static/img/classify_yundongxie4.jpg", b: "篮球鞋"},
                  {a: "../../../static/img/classify_yundongxie5.jpg", b: "帆布鞋"},
                  {a: "../../../static/img/classify_yundongxie6.jpg", b: "训练鞋"},
                  {a: "../../../static/img/classify_yundongxie7.jpg", b: "拖鞋"},
                  {a: "../../../static/img/classify_yundongxie8.jpg", b: "网球鞋"},
                  {a: "../../../static/img/classify_yundongxie9.jpg", b: "羽毛球鞋"},
                ],
              },
              {
                bantitls: "健身器材",
                hot: [
                  {a: "../../../static/img/classify_playqicai1.jpg", b: "跑步机"},
                  {a: "../../../static/img/classify_playqicai2.jpg", b: "仰卧板"},
                  {a: "../../../static/img/classify_playqicai3.jpg", b: "甩脂机"},
                  {a: "../../../static/img/classify_playqicai4.jpg", b: "健腹轮"},
                  {a: "../../../static/img/classify_playqicai5.jpg", b: "健身车"},
                  {a: "../../../static/img/classify_playqicai6.jpg", b: "哑铃"},
                  {a: "../../../static/img/classify_playqicai7.jpg", b: "拉力器"},
                  {a: "../../../static/img/classify_playqicai8.jpg", b: "划船机"},
                  {a: "../../../static/img/classify_playqicai9.jpg", b: "踏步机"},
                  {a: "../../../static/img/classify_playqicai10.jpg", b: "椭圆机"},
                  {a: "../../../static/img/classify_playqicai11.jpg", b: "跳绳"},
                  {a: "../../../static/img/classify_playqicai12.jpg", b: "计步器"},
                  {a: "../../../static/img/classify_playqicai13.jpg", b: "握力器"},
                  {a: "../../../static/img/classify_playqicai14.jpg", b: "综合训练器"},
                  {a: "../../../static/img/classify_playqicai15.jpg", b: "运动护具"},
                  {a: "../../../static/img/classify_playqicai16.jpg", b: "瑜伽用品"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_play1.jpg"
          },
          {
            title: "苏宁国际",
            bansrc: "../../../static/img/classify_guoji1.jpg",
            product:[
              {
                bantitls: "国际名牌",
                hot: [
                  {a: "../../../static/img/classify_guojibrand1.jpg",b:"Swisse"},
                  {a: "../../../static/img/classify_guojibrand2.jpg",b:"资生堂"},
                  {a: "../../../static/img/classify_guojibrand3.jpg",b:"膳魔师"},
                  {a: "../../../static/img/classify_guojibrand4.jpg",b:"Schiff"},
                  {a: "../../../static/img/classify_guojibrand5.jpg",b:"芙拉"},
                  {a: "../../../static/img/classify_guojibrand6.jpg",b:"诺优能"},
                  {a: "../../../static/img/classify_guojibrand7.jpg",b:"任天堂"},
                  {a: "../../../static/img/classify_guojibrand8.jpg",b:"ReFa"},
                  {a: "../../../static/img/classify_guojibrand9.jpg",b:"爱他美"},

                ],
              },
              {
                bantitls: "母婴儿童",
                hot: [
                  {a: "../../../static/img/classify_muying1.jpg", b: "奶粉"},
                  {a: "../../../static/img/classify_muying2.jpg", b: "纸尿裤"},
                  {a: "../../../static/img/classify_muying3.jpg", b: "营养辅食"},
                  {a: "../../../static/img/classify_muying4.jpg", b: "婴儿用品"},
                  {a: "../../../static/img/classify_muying5.jpg", b: "婴儿洗护"},
                  {a: "../../../static/img/classify_muying6.jpg", b: "童车童床"},
                  {a: "../../../static/img/classify_muying7.jpg", b: "儿童玩具"},
                  {a: "../../../static/img/classify_muying8.jpg", b: "童装童鞋"},
                ],
              },
              {
                bantitls: "彩妆面护",
                hot: [
                  {a: "../../../static/img/classify_caizhuang1.jpg", b: "防晒"},
                  {a: "../../../static/img/classify_caizhuang2.jpg", b: "面部护理"},
                  {a: "../../../static/img/classify_caizhuang3.jpg", b: "面膜"},
                  {a: "../../../static/img/classify_caizhuang4.jpg", b: "口红"},
                  {a: "../../../static/img/classify_caizhuang5.jpg", b: "彩妆"},
                  {a: "../../../static/img/classify_caizhuang6.jpg", b: "护肤套装"},
                  {a: "../../../static/img/classify_caizhuang7.jpg", b: "香水香氛"},
                  {a: "../../../static/img/classify_caizhuang8.jpg", b: "洁面仪"},
                  {a: "../../../static/img/classify_caizhuang9.jpg", b: "卸妆"},

                ],
              },
              {
                bantitls: "营养保健",
                hot: [
                  {a: "../../../static/img/classify_baojian1.jpg", b: "膳食补充剂"},
                  {a: "../../../static/img/classify_baojian2.jpg", b: "提高免疫"},
                  {a: "../../../static/img/classify_baojian3.jpg", b: "维生素/矿物质"},
                  {a: "../../../static/img/classify_baojian4.jpg", b: "美容养颜"},
                  {a: "../../../static/img/classify_baojian5.jpg", b: "调节三高"},
                  {a: "../../../static/img/classify_baojian6.jpg", b: "减肥瘦身"},
                  {a: "../../../static/img/classify_baojian7.jpg", b: "胶原蛋白"},
                  {a: "../../../static/img/classify_baojian8.jpg", b: "补肾强身"},
                  {a: "../../../static/img/classify_baojian9.jpg", b: "养生茶饮"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_guoji2.jpg"
          },
          {
            title: "礼品乐器",
            bansrc: "../../../static/img/classify_gift1.jpg",
            product:[
              {
                bantitls: "礼品",
                hot: [
                  {a: "../../../static/img/classify_giftb1.jpg",b:"创意礼品"},
                  {a: "../../../static/img/classify_giftb2.jpg",b:"打火机"},
                  {a: "../../../static/img/classify_giftb3.jpg",b:"电子烟"},
                  {a: "../../../static/img/classify_giftb4.jpg",b:"工艺摆件"},
                  {a: "../../../static/img/classify_giftb5.jpg",b:"婚庆节庆"},
                  {a: "../../../static/img/classify_giftb6.jpg",b:"礼物"},
                  {a: "../../../static/img/classify_giftb7.jpg",b:"瑞士军刀"},
                  {a: "../../../static/img/classify_giftb8.jpg",b:"收藏品"},
                  {a: "../../../static/img/classify_giftb9.jpg",b:"zippo打火机"},
                  {a: "../../../static/img/classify_giftb10.jpg",b:"充电打火机"},
                  {a: "../../../static/img/classify_giftb11.jpg",b:"烟嘴"},
                  {a: "../../../static/img/classify_giftb12.jpg",b:"烟酒"},
                  {a: "../../../static/img/classify_giftb13.jpg",b:"烟斗"},
                  {a: "../../../static/img/classify_giftb14.jpg",b:"烟盒"},
                  {a: "../../../static/img/classify_giftb15.png",b:"电子烟套装"},
                  {a: "../../../static/img/classify_giftb16.png",b:"礼品定制"},
                  {a: "../../../static/img/classify_giftb17.png",b:"佛道"},

                ],
              },
              {
                bantitls: "乐器",
                hot: [
                  {a: "../../../static/img/classify_yueqi1.jpg", b: "电钢琴"},
                  {a: "../../../static/img/classify_yueqi2.jpg", b: "电子鼓"},
                  {a: "../../../static/img/classify_yueqi3.jpg", b: "二胡"},
                  {a: "../../../static/img/classify_yueqi4.jpg", b: "钢琴"},
                  {a: "../../../static/img/classify_yueqi5.jpg", b: "古琴"},
                  {a: "../../../static/img/classify_yueqi6.jpg", b: "古筝"},
                  {a: "../../../static/img/classify_yueqi7.jpg", b: "吉他"},
                  {a: "../../../static/img/classify_yueqi8.jpg", b: "口琴"},
                  {a: "../../../static/img/classify_yueqi9.jpg", b: "小提琴"},
                  {a: "../../../static/img/classify_yueqi10.jpg", b: "乐器配件"},
                  {a: "../../../static/img/classify_yueqi11.jpg", b: "打击乐器"},
                  {a: "../../../static/img/classify_yueqi12.jpg", b: "电子琴"},
                  {a: "../../../static/img/classify_yueqi13.jpg", b: "手风琴"},
                  {a: "../../../static/img/classify_yueqi14.jpg", b: "尤克里里"},
                  {a: "../../../static/img/classify_yueqi15.jpg", b: "工艺礼品乐器"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_gift2.jpg"
          },
          {
            title: "医药馆",
            bansrc: "../../../static/img/classify_yiyao.jpg",
            product:[
              {
                bantitls: "中西药品",
                hot: [
                  {a: "../../../static/img/classify_zhongxiyao1.jpg",b:"感冒咳嗽"},
                  {a: "../../../static/img/classify_zhongxiyao2.jpg",b:"妇科用药"},
                  {a: "../../../static/img/classify_zhongxiyao3.jpg",b:"男科用药"},
                  {a: "../../../static/img/classify_zhongxiyao4.jpg",b:"补气补血"},
                  {a: "../../../static/img/classify_zhongxiyao5.jpg",b:"抗菌消炎"},
                  {a: "../../../static/img/classify_zhongxiyao6.jpg",b:"泌尿生殖"},
                  {a: "../../../static/img/classify_zhongxiyao7.jpg",b:"心脑血管"},
                  {a: "../../../static/img/classify_zhongxiyao8.jpg",b:"解热镇痛"},
                  {a: "../../../static/img/classify_zhongxiyao9.jpg",b:"风湿骨伤"},
                  {a: "../../../static/img/classify_zhongxiyao10.jpg",b:"维矿物质"},
                  {a: "../../../static/img/classify_zhongxiyao11.jpg",b:"肝胆用药"},
                  {a: "../../../static/img/classify_zhongxiyao12.jpg",b:"健脾益肾"},
                  {a: "../../../static/img/classify_zhongxiyao13.jpg",b:"眼科用药"},
                  {a: "../../../static/img/classify_zhongxiyao14.jpg",b:"癣症"},
                  {a: "../../../static/img/classify_zhongxiyao15.jpg",b:"小儿感冒"},
                  {a: "../../../static/img/classify_zhongxiyao16.jpg",b:"小儿胃肠"},
                  {a: "../../../static/img/classify_zhongxiyao17.jpg",b:"抗病毒类"},
                  {a: "../../../static/img/classify_zhongxiyao18.jpg",b:"脱发/白发"},
                  {a: "../../../static/img/classify_zhongxiyao19.jpg",b:"小儿维矿"},
                  {a: "../../../static/img/classify_zhongxiyao20.jpg",b:"安神补脑"},
                  {a: "../../../static/img/classify_zhongxiyao21.jpg",b:"抗眩晕"},
                  {a: "../../../static/img/classify_zhongxiyao22.jpg",b:"避孕药"},
                  {a: "../../../static/img/classify_zhongxiyao23.jpg",b:"耳鼻喉"},
                  {a: "../../../static/img/classify_zhongxiyao24.jpg",b:"胃肠用药"},

                ],
              },
              {
                bantitls: "医疗器械",
                hot: [
                  {a: "../../../static/img/classify_yiliaoqixie1.jpg", b: "制氧机"},
                  {a: "../../../static/img/classify_yiliaoqixie2.jpg", b: "血压计"},
                  {a: "../../../static/img/classify_yiliaoqixie3.jpg", b: "助听器"},
                  {a: "../../../static/img/classify_yiliaoqixie4.jpg", b: "体温计"},
                  {a: "../../../static/img/classify_yiliaoqixie5.jpg", b: "雾化器"},
                  {a: "../../../static/img/classify_yiliaoqixie6.jpg", b: "拔罐器"},
                  {a: "../../../static/img/classify_yiliaoqixie7.jpg", b: "轮椅/助行器"},
                  {a: "../../../static/img/classify_yiliaoqixie8.jpg", b: "牵引器"},
                  {a: "../../../static/img/classify_yiliaoqixie9.jpg", b: "呼吸机"},
                  {a: "../../../static/img/classify_yiliaoqixie10.jpg", b: "贴膏"},
                  {a: "../../../static/img/classify_yiliaoqixie11.jpg", b: "保健理疗"},
                  {a: "../../../static/img/classify_yiliaoqixie12.jpg", b: "血糖仪"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_yiyao1.jpg"
          },
          {
            title: "特色馆",
            bansrc: "../../../static/img/classify_yiyao.jpg",
            product:[
              {
                bantitls: "热销品类",
                hot: [
                  {a: "../../../static/img/classify_tesehot1.jpg",b:"水果"},
                  {a: "../../../static/img/classify_tesehot3.jpg",b:"零食"},
                  {a: "../../../static/img/classify_tesehot2.jpg",b:"茶叶"},
                  {a: "../../../static/img/classify_tesehot4.jpg",b:"酒"},
                  {a: "../../../static/img/classify_tesehot5.jpg",b:"大米"},
                  {a: "../../../static/img/classify_tesehot7.jpg",b:"干货"},
                  {a: "../../../static/img/classify_tesehot8.jpg",b:"肉类"},
                  {a: "../../../static/img/classify_tesehot9.jpg",b:"水产"},
                  {a: "../../../static/img/classify_tesehot10.jpg",b:"蛋类"},

                ],
              },
              {
                bantitls: "华东特色",
                hot: [
                  {a: "../../../static/img/classify_huadong1.jpg", b: "高邮咸鸭蛋"},
                  {a: "../../../static/img/classify_huadong2.jpg", b: "莆田桂圆干"},
                  {a: "../../../static/img/classify_huadong3.jpg", b: "婺源菊花茶"},
                  {a: "../../../static/img/classify_huadong4.jpg", b: "景德镇陶瓷"},
                  {a: "../../../static/img/classify_huadong5.jpg", b: "砀山黄桃"},
                  {a: "../../../static/img/classify_huadong6.jpg", b: "武夷大红袍"},
                ],
              },
            ],
            pingdao:"../../../static/img/classify_tese1.jpg"
          },
          {
            title: "艺术陶瓷",
            bansrc: "../../../static/img/Classification_right1.jpg",
            bantitle: "热门专场",
            special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
            bantitls: "热门推荐",
            hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
              {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
              {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
              {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
              {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
              {a: "../../../static/img/Classification_right7.png", b: "热水器"},
              {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
              {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
              {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
            ],
            bantitsrc: "../../../static/img/Classification_right10.png",
            bantite: "为您推荐",
            recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
              {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
              {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
              {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
              {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
              {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
              {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
              {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
              {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
            ]
          },
        ]
      }
    },
   mounted() {
      new Swiper('.swiper-container', {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
          delay: 2500,
          disableOnInteraction: false,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        loop: true,
        observer: true,
        observeParents: true,
      });
    },
    methods: {
      addClass: function (index) {
        this.current = index;
      }

    }
  }
</script>

<style scoped>
  .box {
    width: 100%;
    -webkit-flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    background-color: #fff;
  }

  nav {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }

  .nav_left {
    position: fixed;
    width: .87rem;
    height: 100%;
    background-color: #f4f4f4;
    /*float: left;*/
    display: -webkit-flex;
    overflow: hidden;
    overflow-y: auto;
  }

  .nav_left .uls {
    display: inline-block;
    width: 0.87rem;
    height: 100%;
  }

  .nav_left .uls li {
    display: block;
    width: .87rem;
    height: .46rem;
    border-bottom: 1px solid #ececec;
  }

  .nav_left .uls li a {
    display: block;
    width: 0.87rem;
    height: 0.46rem;
    line-height: 0.46rem;
    text-align: center;
    font-size: .12rem;
    float: left;
    color: #666666;
  }

  .swiper-container {
    width: 100%;
    height: 1rem;
    overflow: hidden;
    position: relative;
  }

  .swiper-wrapper {
    width: 100%;
    height: 100%;
    display: flex;
    flex: 0;
  }

  .swiper-slide {
    width: 2.7rem;
    height: 1rem;
  }

  .swiper-slide img {
    width: 2.7rem;
    height: 1rem;
  }

  .swiper-pagination {
    position: absolute;
    top: 0;
    left: 0;
  }

  .swiper-pagination span {
    width: .1rem;
    height: .02rem;
    background-color: #ff6600;
  }

  .uls .lis {
    display: block;
    width: .7rem;
    border-left: .03rem solid #ff6600;
    background-color: #fff;
  }

  .nav_left .uls .lis a {
    color: #ff6600;
  }

  .nav_right {
    width: 2.87rem;
    height: 100%;
    padding: .1rem;
    float: right;

  }

  .nav_box {
    width: 2.7rem;
    height: 100%;
    /* display: none; */
  }

  .nav_banner {
    width: 100%;
    height: 1rem;
  }

  .nav_banner a {
    display: block;
    width: 100%;
    height: 1rem;
  }

  .nav_banner a img {
    display: block;
    width: 100%;
    height: 1rem;
  }

  .nav_title {
    width: 100%;
    color: #FF6600;
    text-align: center;
    font-size: .12rem;
    line-height: .62rem;
  }

  .hot_special {
    width: 100%;
    overflow: hidden;
  }

  .hot_special a {
    display: block;
    width: 1.3rem;
    height: .4rem;
    float: left;
  }

  .hot_special a img {
    display: block;
    width: 1.3rem;
    height: .4rem;
  }

  .hot_special a:nth-of-type(1) {
    margin-bottom: .3rem;
    margin-right: .07rem;
  }

  .hot_special a:nth-of-type(2) {
    margin-bottom: .3rem;
  }

  .hot_special a:nth-of-type(3) {
    margin-right: .07rem;
  }

  .nav_titles {
    width: 100%;
    height: .18rem;
    color: #FF6600;
    text-align: left;
    margin-top: .3rem;
    margin-bottom: .2rem;
    font-size: .12rem;
  }

  .hot_recommendation {
    width: 100%;
    overflow: hidden;
  }

  .hot_recommendation ul li {
    display: block;
    width: .89rem;
    height: .85rem;
    margin-bottom: .15rem;
    float: left;
  }

  .hot_recommendation ul li a {
    display: block;
    width: .9rem;
    height: .85rem;
  }

  .hot_recommendation ul li a img {
    display: block;
    width: .6rem;
    height: .6rem;
    margin-left: .13rem;
    margin-bottom: .05rem;
  }

  .hot_recommendation ul li a em {
    display: block;
    width: .89rem;
    height: .2rem;
    line-height: .2rem;
    text-align: center;
    font-size: .12rem;
    color: #666;
  }

  .nav_titlet {
    width: 100%;
  }

  .nav_titlet em {
    color: #FF6600;
    font-size: .12rem;
    float: left;
  }

  .nav_titlet em img {
    width: .13rem;
    height: .13rem;
    display: block;
    margin-left: 1rem;
    margin-top: .015rem;
    margin-right: .02rem;
    float: left;
    vertical-align: middle;
  }

  .recommendations {
    width: 100%;
   overflow: hidden;
  }

  .recommendations ul li {
    float: left;
    width: .59rem;
    height: .82rem;
    margin-top: .2rem;
    margin-left: .15rem;
    margin-right: .15rem;
  }

  .recommendations ul li a {
    display: block;
    margin: 0 auto;
    width: .6rem;
    height: .82rem;
  }

  .recommendations ul li a img {
    display: block;
    width: .6rem;
    height: .6rem;
  }

  .recommendations ul li a em {
    display: block;
    width: .6rem;
    height: .12rem;
    margin-top: .1rem;
    font-size: .12rem;
    color: #666666;
    line-height: .12rem;
    text-align: center;
  }
  .pingdao{
    width:100%;
  }
</style>
