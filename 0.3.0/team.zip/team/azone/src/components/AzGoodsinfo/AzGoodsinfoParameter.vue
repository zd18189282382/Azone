<template>
  <div>
    <div class="parameter">
      <div class="awrap">
        <div class="awrapTit">
          商品参数
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>系统</dt>
              <dd>
                <span>手机操作系统</span>
                <span> Android </span>
              </dd>
              <dd>
                <span>系统版本</span>
                <span>  基于Android 8.1开发的ColorOS 5.2 </span>
              </dd>
              <dd>
                <span>手机操控方式</span>
                <span> 电容触摸屏 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>拍照</dt>
              <dd>
                <span>摄像头类型</span>
                <span> 前单+后双 </span>
              </dd>
              <dd>
                <span>前摄像头</span>
                <span> 2500万像素 </span>
              </dd>
              <dd>
                <span>前摄像头数量</span>
                <span> 1个 </span>
              </dd>
              <dd>
                <span>前摄光圈大小</span>
                <span> f/2.0光圈 </span>
              </dd>
              <dd>
                <span>后摄像头</span>
                <span>  1600万像素  </span>
              </dd>
              <dd>
                <span>后置摄像头数量</span>
                <span>  2  </span>
              </dd>
              <dd>
                <span>后摄光圈大小</span>
                <span>  f/2.4光圈  </span>
              </dd>
              <dd>
                <span>闪光灯类型</span>
                <span> LED </span>
              </dd>
              <dd>
                <span>变焦模式</span>
                <span> 数码变焦 </span>
              </dd>
              <dd>
                <span>拍照特点</span>
                <span> 美颜,连拍,全景,滤镜,场景模式,HDR,自动对焦 </span>
              </dd>
              <dd>
                <span>传感器类型</span>
                <span>  CMOS  </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
        <div class="awrapAll">
          <div class="zhuti">
            <dl>
              <dt>主体</dt>
              <dd>
                <span>品牌</span>
                <span>OPPO</span>
              </dd>
              <dd>
                <span>型号</span>
                <span> OPPO K1 </span>
              </dd>
              <dd>
                <span>上市时间</span>
                <span>  2018.10</span>
              </dd>
              <dd>
                <span>产品名称</span>
                <span> OPPO K1 </span>
              </dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "AzGoodsinfoParameter"
  }
</script>

<style scoped>
  .parameter {
    width: 100%;
    background:white;
    margin-bottom:.5rem;
  }
  .awrap{
    width:100%;
    padding:.12rem .13rem;
    box-sizing: border-box;
  }
  .awrapTit{
    width:100%;
    height:.52rem;
    line-height:.52rem;
    font-size:.14rem;
    color:#353d44;
    position:relative;
  }
  .zhuti{
    border-top:1px dashed #dcdcdc;
    padding-top:.1rem;
  }
  .zhuti dl{
    color:#909090;
    font-size:.12rem;
    line-height:.28rem;
  }
  .zhuti dl dd{
    display:flex;
  }
  .zhuti dl dd span{
    display:block;
  }
  .zhuti dl dd span:first-child{
    width:1.15rem;
  }
  .zhuti dl dd span:last-child{
    width:1.7rem;
  }
</style>
