<template>
  <div>
    <div class="Graphic">
      <img src="../../../static/img/goodsinfo_tu1.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu2.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu3.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu4.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu5.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu6.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu7.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu8.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu9.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu10.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu11.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu12.jpg" alt=""/>
      <img src="../../../static/img/goodsinfo_tu13.jpg" alt=""/>
    </div>
  </div>
</template>

<script>
    export default {
        name: "AzGoodsinfoGraphic"
    }
</script>

<style scoped>
  .Graphic{
    width:100%;
    background:white;
    margin-bottom:.5rem;
  }
  .Graphic img{
    width:100%;
  }
</style>
