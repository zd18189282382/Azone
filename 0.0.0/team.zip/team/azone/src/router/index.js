import Vue from 'vue'
import Router from 'vue-router'
import AzIndex from '../pages/AzIndex'
import AzClassification from "../pages/AzClassification"
import AzGoodslist from '../pages/AzGoodslist'
import AzGoodslistZonghe from '../components/AzGoodslist/AzGoodslistZonghe'
import AzGoodslistXiaoliang from '../components/AzGoodslist/AzGoodslistXiaoliang'
import AzGoodslistJiage from '../components/AzGoodslist/AzGoodslistJiage'
import AzGoodslistShaixuan from '../components/AzGoodslist/AzGoodslistShaixuan'
Vue.use(Router)

export default new Router({
  mode:"history",
  linkExactActiveClass:"xxx",
  routes: [
    {
      path: '/',
      name: 'AzIndex',
      component: AzIndex
    },
    {
      path: '/az',
      name: 'AzClassification',
      component: AzClassification
    },
    {
      path: '/AzGoodslist',
      name: 'AzGoodslist',
      component: AzGoodslist,
      children:[
        {
          path:"",
          component:AzGoodslistZonghe
        },
        {
          path:"AzGoodslistXiaoliang",
          component:AzGoodslistXiaoliang
        },
        {
          path:"AzGoodslistJiage",
          component:AzGoodslistJiage
        },
        {
          path:"AzGoodslistShaixuan",
          component:AzGoodslistShaixuan
        }
      ]
    }
  ]
})
