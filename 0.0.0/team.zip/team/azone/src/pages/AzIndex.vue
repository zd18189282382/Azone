<template>
  <div class="box">
    <az-index-header></az-index-header>
    <az-index-banner></az-index-banner>
    <az-index-classify></az-index-classify>
    <az-index-headline></az-index-headline>
    <az-index-newbie></az-index-newbie>
    <azone-index-sale></azone-index-sale>
    <az-index-everyday></az-index-everyday>
    <az-index-banner-small></az-index-banner-small>
    <az-index-brand></az-index-brand>
    <az-index-furniture></az-index-furniture>
    <az-index-banner-small></az-index-banner-small>
    <az-index-life></az-index-life>
    <az-index-financial></az-index-financial>
    <az-index-market></az-index-market>
    <az-index-goodshop></az-index-goodshop>
    <az-index-youlike></az-index-youlike>
    <az-index-versions></az-index-versions>
    <az-index-footer></az-index-footer>
    <az-index-return></az-index-return>
  </div>
</template>

<script>
  import AzIndexHeader from "../components/AzIndex/AzIndexHeader";
  import AzIndexBanner from "../components/AzIndex/AzIndexBanner";
  import AzIndexClassify from "../components/AzIndex/AzIndexClassify";
  import AzIndexHeadline from "../components/AzIndex/AzIndexHeadline";
  import AzIndexNewbie from "../components/AzIndex/AzIndexNewbie";
  import AzoneIndexSale from "../components/AzIndex/AzoneIndexSale";
  import AzIndexEveryday from "../components/AzIndex/AzIndexEveryday";
  import AzIndexBannerSmall from "../components/AzIndex/AzIndexBannerSmall";
  import AzIndexMarket from "../components/AzIndex/AzIndexMarket";
  import AzIndexGoodshop from "../components/AzIndex/AzIndexGoodshop";
  import AzIndexYoulike from "../components/AzIndex/AzIndexYoulike";
  import AzIndexFooter from "../components/AzIndex/AzIndexFooter";
  import AzIndexVersions from "../components/AzIndex/AzIndexVersions";
  import AzIndexReturn from "../components/AzIndex/AzIndxReturn";
  import AzIndexBrand from "../components/AzIndex/AzIndexBrand";
  import AzIndexFurniture from "../components/AzIndex/AzIndexFurniture";
  import AzIndexLife from "../components/AzIndex/AzIndexLife";
  import AzIndexFinancial from "../components/AzIndex/AzIndexFinancial";

  export default {
    name: "AzIndex",
    components: {
      AzIndexFinancial,
      AzIndexLife,
      AzIndexFurniture,
      AzIndexBrand,
      AzIndexReturn,
      AzIndexVersions,
      AzIndexFooter,
      AzIndexYoulike,
      AzIndexGoodshop,
      AzIndexMarket,
      AzIndexBannerSmall,
      AzIndexEveryday,
      AzoneIndexSale, AzIndexNewbie, AzIndexHeadline, AzIndexClassify, AzIndexBanner, AzIndexHeader
    }
  }
</script>

<style>
  @import "../assets/css/AzIndex.css";

  .box {
    width: 3.75rem;
    overflow-x: hidden;
  }
</style>
