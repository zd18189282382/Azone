<template>
  <div class="box">
    <nav>
      <div class="nav_left">
        <ul class="uls">
          <li   v-for="(p,index) in see" v-on:click="addClass(index)" v-bind:class="{ lis:index==current}"><a href="#">{{p.title}}</a></li>
        </ul>
      </div>
      <div class="nav_right">
        <div class="nav_box">
          <div class="nav_banner">
            <a href="#" v-show="see[current].bansrc"><img :src="see[current].bansrc" alt=""></a>
            <div class="swiper-container" v-show="see[current].bansrcs">
              <div class="swiper-wrapper">
                <div class="swiper-slide" :key="index" v-for="(p,index) in see[current].bansrcs"><img :src="p" alt=""></div>

              <div class="swiper-pagination"></div>
            </div>
          </div>
          </div>
          <div class="nav_title">
            <p>{{see[current].bantitle}}</p>
          </div>
          <div class="hot_special">
            <a href="/AzGoodslist" :key="index"  v-for="(p,index) in see[current].special"><img :src="p" alt=""></a>

          </div>
          <div class="nav_titles">
            <p>{{see[current].bantitls}}</p>
          </div>
          <div class="hot_recommendation">
            <ul>
              <li :key="index" v-for="(p,index) in see[current].hot"><a href="#"><img :src="p.a" alt=""><em>{{p.b}}</em></a></li>

            </ul>
          </div>
          <div class="nav_titlet">
            <em><img :src="see[current].bantitsrc" alt="">{{see[current].bantite}}</em>
          </div>
          <div class="recommendations">
            <ul>
              <li :key="index" v-for="(p,index) in see[current].recomm"><a href="#"><img :src="p.a" alt=""><em>{{p.b}}</em></a></li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  </div>

</template>

<script>
  import Swiper from "swiper"
    export default {
        name: "AzClassificationBox",
      data() {
        return {
          current: 0,
          see: [
            {
              title: "热门推荐",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "大家电",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门家电",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]

            },
            {
              title: "手机相册",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "电脑办公",
              bansrcs:["../../../static/img/Classification_computer1.png","../../../static/img/Classification_computer1.jpg"],
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "厨卫大电",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "生活家电",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "人群偏爱",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "食品酒水",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "居家生活",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "品质男装",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "运动户外",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "苏宁国际",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "礼品乐器",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "艺术陶瓷",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "医药馆",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "特色馆",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "苏宁金融",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            },
            {
              title: "苏宁有房",
              bansrc: "../../../static/img/Classification_right1.jpg",
              bantitle: "热门专场",
              special: ["../../../static/img/Classification_right1.png", "../../../static/img/Classification_right2.png", "../../../static/img/Classification_right3.png", "../../../static/img/Classification_right4.png"],
              bantitls: "热门推荐",
              hot: [{a: "../../../static/img/Classification_right2.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right3.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right4.jpg", b: "洗衣机"},
                {a: "../../../static/img/Classification_right5.jpg", b: "取暖器"},
                {a: "../../../static/img/Classification_right6.png", b: "空气净化器"},
                {a: "../../../static/img/Classification_right7.png", b: "热水器"},
                {a: "../../../static/img/Classification_right8.jpg", b: "手机"},
                {a: "../../../static/img/Classification_right9.jpg", b: "笔记本"},
                {a: "../../../static/img/Classification_right10.jpg", b: "奶粉"},
              ],
              bantitsrc: "../../../static/img/Classification_right10.png",
              bantite: "为您推荐",
              recomm: [{a: "../../../static/img/Classification_right11.jpg", b: "电磁炉"},
                {a: "../../../static/img/Classification_right12.jpg", b: "茶饮料"},
                {a: "../../../static/img/Classification_right13.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right14.jpg", b: "收纳用品"},
                {a: "../../../static/img/Classification_right15.jpg", b: "电动剃须刀"},
                {a: "../../../static/img/Classification_right16.jpg", b: "薯片"},
                {a: "../../../static/img/Classification_right7.jpg", b: "组装机"},
                {a: "../../../static/img/Classification_right8.jpg", b: "显示器"},
                {a: "../../../static/img/Classification_right9.jpg", b: "电磁炉"},
              ]
            }
            ]
        }
      },
      updated(){
          new Swiper('.swiper-container', {
          spaceBetween: 30,
          centeredSlides: true,
          autoplay: {
            delay: 2500,
            disableOnInteraction: false,
          },
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
          },
          loop:true,
          observer:true,
          observeParents:true,
        });
      },
      methods:{
        addClass:function(index){
          this.current=index;
        }

      }
    }
</script>

<style scoped>
  .box{
    width:100%;
    -webkit-flex:1;
    overflow-y:auto;
    overflow-x: hidden;
    background-color: #fff;
  }
  nav{
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
  .nav_left{
    width: .87rem;
    height: 100%;
    background-color: #f4f4f4;
    float: left;
    display: -webkit-flex;
    overflow-y: auto;
  }
  .nav_left .uls{
    display: inline-block;
    width: 0.87rem;
    height: 100%;
  }
  .nav_left .uls li{
    display: block;
    width: .87rem;
    height: .46rem;
    border-bottom: 1px solid #ececec;
  }
  .nav_left .uls li a{
    display: block;
    width: 0.87rem;
    height: 0.46rem;
    line-height: 0.46rem;
    text-align: center;
    font-size: .12rem;
    float: left;
    color: #666666;
  }
  .swiper-container{
    width:100%;
    height: 1rem;
    overflow: hidden;
    position:relative;
  }
  .swiper-wrapper{
    width:100%;
    height:100%;
    display:flex;
    flex:0;
  }
  .swiper-slide{
    width:2.7rem;
    height: 1rem;
  }
  .swiper-slide img{
    width:2.7rem;
    height: 1rem;
  }
  .swiper-pagination{
    position: absolute;
    top: 0;
    left: 0;
  }
  .swiper-pagination span{
    width: .1rem;
    height: .02rem;
    background-color: #ff6600;
  }
  .uls .lis{
    display: block;
    width: .7rem;
    border-left: .03rem solid #ff6600;
    background-color: #fff;
  }
  .nav_left .uls .lis a{
    color: #ff6600;
  }
  .nav_right{
    width: 2.87rem;
    height: 100%;
    padding: .1rem;
    overflow-y: auto;
  }
  .nav_box{
    width: 2.7rem;
    height: 100%;
    /* display: none; */
  }
  .nav_banner{
    width: 100%;
    height: 1rem;
  }
  .nav_banner a{
    display: block;
    width: 100%;
    height: 1rem;
  }
  .nav_banner a img{
    display: block;
    width: 100%;
    height: 1rem;
  }
  .nav_title{
    width: 100%;
    height: .18rem;
    color: #FF6600;
    text-align: center;
    margin-top: .3rem;
    margin-bottom: .2rem;
    font-size: .12rem;
  }
  .hot_special{
    width: 100%;
    height: 1.1rem;
  }
  .hot_special a{
    display: block;
    width: 1.3rem;
    height: .4rem;
    float: left;
  }
  .hot_special a img{
    display: block;
    width: 1.3rem;
    height: .4rem;
  }
  .hot_special a:nth-of-type(1){
    margin-bottom: .3rem;
    margin-right: .07rem;
  }
  .hot_special a:nth-of-type(2){
    margin-bottom: .3rem;
  }
  .hot_special a:nth-of-type(3){
    margin-right: .07rem;
  }
  .nav_titles{
    width: 100%;
    height: .18rem;
    color: #FF6600;
    text-align: left;
    margin-top: .3rem;
    margin-bottom: .2rem;
    font-size: .12rem;
  }
  .hot_recommendation{
    width: 100%;
    height: 4.1rem;
  }
  .hot_recommendation ul li{
    display: block;
    width: .89rem;
    height: .85rem;
    margin-top: .15rem;
    float: left;
  }
  .hot_recommendation ul li a{
    display: block;
    width: .9rem;
    height: .85rem;
  }
  .hot_recommendation ul li a img{
    display: block;
    width: .6rem;
    height: .6rem;
    margin-left: .13rem;
    margin-bottom: .05rem;
  }
  .hot_recommendation ul li a em{
    display: block;
    width: .89rem;
    height: .2rem;
    line-height: .2rem;
    text-align: center;
    font-size: .12rem;
    color: #666;
  }
  .nav_titlet{
    width: 100%;
    height: .18rem;
    margin-top: .3rem;
    margin-bottom: .2rem;
  }
  .nav_titlet em{
    color: #FF6600;
    font-size: .12rem;
    float: left;
  }
  .nav_titlet em img{
    width: .13rem;
    height: .13rem;
    display: block;
    margin-left: 1rem;
    margin-top: .015rem;
    margin-right: .02rem;
    float: left;
    vertical-align: middle;
  }
  .recommendations{
    width: 100%;
    height:3.3rem;
  }
  .recommendations ul li{
    float: left;
    width: .59rem;
    height: .82rem;
    margin-top: .2rem;
    margin-left: .15rem;
    margin-right: .15rem;
  }
  .recommendations ul li a{
    display: block;
    margin: 0 auto;
    width: .6rem;
    height: .82rem;
  }
  .recommendations ul li a img{
    display: block;
    width: .6rem;
    height: .6rem;
  }
  .recommendations ul li a em{
    display: block;
    width: .6rem;
    height: .12rem;
    margin-top: .1rem;
    font-size: .12rem;
    color: #666666;
    line-height: .12rem;
    text-align: center;
  }
</style>
