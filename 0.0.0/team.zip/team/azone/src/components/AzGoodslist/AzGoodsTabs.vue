<template>
    <div>
      <ul>
        <router-link tag="li" to="/AzGoodslist">综合</router-link>
        <router-link tag="li" to="/AzGoodslist/AzGoodslistXiaoliang">销量</router-link>
        <router-link tag="li" to="/AzGoodslist/AzGoodslistJiage">价格</router-link>
        <router-link tag="li" to="/AzGoodslist/AzGoodslistShaixuan">筛选</router-link>
      </ul>
      <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: "AzGoodsTabs"
    }
</script>

<style scoped>
  .xxx{
    color:#f60;
  }
  ul{
    display:flex;
    width:100%;
    background: #fff;
    border-bottom:1px solid #f2f2f2;
  }
  ul li{
    width:25%;
    height:.44rem;
    font-size:.14rem;
    color:#333;
    text-align: center;
    line-height:.44rem;
  }
</style>
