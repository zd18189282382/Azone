<template>
    <div>
      <div class="htSwiper">

      </div>
    </div>
</template>

<script>
  import Swiper from "swiper"
    export default {
        name: "AzIndexBannerSmall",

    }
</script>

<style scoped>
.htSwiper{
  width:100%;
  height:1rem;
  background:white;
  margin-bottom:.15rem;
}
</style>
