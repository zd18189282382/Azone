<template>
  <div>
    <div class="youlike">
      <img src="../../../static/img/index_youlikeTit.png" alt="" class="youlikeTit"/>
      <ul>
        <li>
          <img src="../../../static/img/index_youlikepro1.jpg" alt=""/>
          <div class="proinfo">
            <i class="zy"></i>
            <i class="sn"></i>
            欧莱雅(LOREAL) 青春密码酵素精华肌底液 50ml 修护;滋润营养 任何肤质 女士适用 乳液质地
          </div>
          <!--<p class="proInfor">-->
            <!--<span>大聚惠</span>-->
            <!--<span>领券100元</span>-->
          <!--</p>-->
          <p class="proprice">￥<span>349</span></p>
        </li>
        <li>
          <img src="../../../static/img/index_youlikepro1.jpg" alt=""/>
          <div class="proinfo">
            <i class="zy"></i>
            <!--<i class="sn"></i>-->
            欧莱雅(LOREAL) 青春密码酵素精华肌底液 50ml 修护;滋润营养 任何肤质 女士适用 乳液质地
          </div>
          <p class="proInfor">
            <span>大聚惠</span>
            <span>领券100元</span>
          </p>
          <p class="proprice">￥<span>349</span></p>
        </li>
        <li>
          <img src="../../../static/img/index_youlikepro1.jpg" alt=""/>
          <div class="proinfo">
            <i class="zy"></i>
            <i class="sn"></i>
            欧莱雅(LOREAL) 青春密码酵素精华肌底液 50ml 修护;滋润营养 任何肤质 女士适用 乳液质地
          </div>
          <p class="proInfor">
            <span>大聚惠</span>
            <span>领券100元</span>
          </p>
          <p class="proprice">￥<span>349</span></p>
        </li>
        <li>
          <img src="../../../static/img/index_youlikepro1.jpg" alt=""/>
          <div class="proinfo">
            <!--<i class="zy"></i>-->
            <!--<i class="sn"></i>-->
            欧莱雅(LOREAL) 青春密码酵素精华肌底液 50ml 修护;滋润营养 任何肤质 女士适用 乳液质地
          </div>
          <p class="proInfor">
            <span>大聚惠</span>
            <span>领券100元</span>
          </p>
          <p class="proprice">￥<span>349</span></p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  export default {
    name: "AzIndexYoulike"
  }
</script>

<style scoped>
  .youlike {
    width: 100%;
    background: white;
  }

  .youlike .youlikeTit {
    width: 100%;
  }
  .youlike ul{
    width:100%;
    display:flex;
    flex-wrap: wrap;
  }
  .youlike ul li{
    width:50%;
    height:2.57rem;
    box-sizing: border-box;
    border-bottom:1px solid #f2f2f2;
  }
  .youlike ul li:nth-child(2n+1){
    border-right:1px solid #f2f2f2;
  }
  .youlike ul li img{
    width:1.6rem;
    height:1.6rem;
    padding:.13rem .13rem 0;
  }
  .proinfo{
     margin:0 .14rem;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    white-space: normal;
    font-size: .12rem;
    position: relative;
  }
  .proinfo .zy{
    display: inline-block;
    width: .3rem;
    height: .14rem;
    background-image: url(../../../static/img/index_youlikeZY.png);
    background-size:.3rem .14rem;
    vertical-align: top;
  }
  .proinfo .sn{
    display: inline-block;
    width: .48rem;
    height: .14rem;
    background-image: url(../../../static/img/index_youlikeXN.png);
    background-size:.48rem .14rem;
    vertical-align: top;
  }
  .proInfor{
    width:100%;
    margin:.02rem .14rem;
    overflow: hidden;
  }
  .proInfor span{
    background: #F60;
    font-size: .12rem;
    line-height: .18rem;
    border-radius: 2px;
    padding: 0 .05rem;
    float: left;
    margin-right: .05rem;
    color: #FFF;
  }
  .proprice{
    font-size: .16rem;
    color: #f40;
    margin: .02rem 0 0 .12rem;
  }
</style>
