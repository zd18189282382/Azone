<template>
    <div>
      <div class="market">
        <img src="../../../static/img/index_marketTit.png" alt="" class="marketTit">
        <ul>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
          <li>
            <p>共筑爱巢</p>
            <p>家具建材市场</p>
            <img src="../../../static/img/index_market1.jpg" alt="">
          </li>
        </ul>
        
      </div>
    </div>
</template>

<script>
    export default {
        name: "AzIndexMarket"
    }
</script>

<style scoped>
  .market{
    width:100%;
    background:white;
    margin-bottom:0.15rem;
  }
  .market .marketTit{
    width:100%;
  }
  .market ul{
    display:flex;
    flex-wrap: wrap;
  }
  .market ul li{
    width:33.3%;
    height:1.30rem;
    box-sizing: border-box;
    border-bottom:1px solid #f2f2f2;
  }
  .market ul li:nth-child(3n+1){
    border-right:1px solid #f2f2f2;
  }
  .market ul li:nth-child(3n-1){
    border-right:1px solid #f2f2f2;
  }
  .market ul li p:first-child{
    margin:.025rem 0 0 .1rem;
    font-size:.16rem;
    font-weight: 800;
    color:#333;
  }
  .market ul li p:nth-child(2){
    margin:.025rem 0 0 .125rem;
    font-size:.12rem;
    color:#999;
  }
  .market ul li img{
    width:.8rem;
    height:.8rem;
    margin:.025rem .22rem 0;
  }
</style>
